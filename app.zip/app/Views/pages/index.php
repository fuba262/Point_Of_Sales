<?= $this -> extend('templates/index');?>


<?= $this ->section('content');?>

<div class="container-fluid">
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Blank Page tester pages</h1>
</div>

<?= $this ->endSection();?>