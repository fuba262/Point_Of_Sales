<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>

<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Tabel Daftar Barang Masuk</h1>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Barang Masuk</h6>
            <button class="btn btn-primary float-right" data-toggle="modal" data-target="#tambahModal">+ Tambah</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id Produk</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Qty</th>
                            <th>Harga Beli</th>
                            <th>Tanggal Masuk (Created_at)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Tabel kosong tanpa data -->
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <button class="btn btn-warning btn-sm">Edit</button>
                                <button class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                        <!-- Tambahkan baris tabel sesuai kebutuhan -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-labelledby="tambahModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahModalLabel">Tambah Barang Masuk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/transaksi/save" method="post">
                    <div class="form-group">
                        <label for="idProduk">Id Produk:</label>
                        <input type="text" class="form-control" id="idProduk" name="idProduk" placeholder="Masukkan Id Produk">
                    </div>
                    <div class="form-group">
                        <label for="namaProduk">Nama Produk:</label>
                        <input type="text" class="form-control" id="namaProduk" name="namaProduk" placeholder="(Auto Complete dari ID Produk)" readonly>
                    </div>
                    <div class="form-group">
                        <label for="kategori">Kategori:</label>
                        <input type="text" class="form-control" id="kategori" name="kategori" placeholder="(Auto Complete dari ID Produk)" readonly>
                    </div>
                    <div class="form-group">
                        <label for="qty">Jumlah Beli:</label>
                        <input type="number" class="form-control" id="qty" name="qty" placeholder="Masukkan Jumlah Beli">
                    </div>
                    <div class="form-group">
                        <label for="hargaBeli">Harga Beli (Rupiah):</label>
                        <input type="text" class="form-control" id="hargaBeli" name="hargaBeli" placeholder="Masukkan Harga Beli">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
           
        </div>
    </div>
</div>

<script>
    document.getElementById('idProduk').addEventListener('change', function() {
        // Misalnya, lakukan AJAX request untuk mendapatkan data produk berdasarkan idProduk
        const idProduk = this.value;

        // Dummy data untuk ilustrasi. Gantilah dengan AJAX request yang sebenarnya.
        const produkData = {
            1: {
                nama: 'Produk A',
                kategori: 'Kategori A'
            },
            2: {
                nama: 'Produk B',
                kategori: 'Kategori B'
            }
        };

        if (produkData[idProduk]) {
            document.getElementById('namaProduk').value = produkData[idProduk].nama;
            document.getElementById('kategori').value = produkData[idProduk].kategori;
        } else {
            document.getElementById('namaProduk').value = '';
            document.getElementById('kategori').value = '';
        }
    });
</script>


<?= $this->endSection(); ?>