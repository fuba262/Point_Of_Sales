<?php

namespace App\Controllers;

class Laporan extends BaseController
{
    public function laporan()
    {
        return view('laporan_masuk');
    }
}
