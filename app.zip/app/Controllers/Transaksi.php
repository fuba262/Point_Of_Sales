<?php

namespace App\Controllers;
use App\Models\TransaksiModel;

class Transaksi extends BaseController
{
    public function barang()
    {

        return view('transaksi_barang');
     
    }

    public function save()
    {
        $model = new TransaksiModel();

        $data = [
            'ID_produk' => $this->request->getPost('idProduk'),
            'Nama_produk' => $this->request->getPost('namaProduk'),
            'Kategori' => $this->request->getPost('kategori'),
            'Qty' => $this->request->getPost('qty'),
            'Harga_Beli' => $this->request->getPost('hargaBeli'),
        ];

        $model->save($data);

        return redirect()->to('/transaksi');
    }


    
}

