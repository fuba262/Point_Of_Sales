<?php namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table = 'produk';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id_produk', 'nama_produk', 'kategori', 'qty', 'harga_beli'];
}
